import os
import shutil

def get_folder_size(folder_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(folder_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)
    return total_size

def format_size(size):
    for unit in ['Б', 'КБ', 'МБ', 'ГБ']:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} ТБ"

def remove_empty_folders(folder_path):
    removed_count = 0
    for root, dirs, files in os.walk(folder_path, topdown=False):
        for dir in dirs:
            dir_path = os.path.join(root, dir)
            try:
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)
                    print(f"Удалена пустая папка: {dir_path}")
                    removed_count += 1
            except Exception as e:
                print(f"Ошибка при удалении папки {dir_path}: {e}")
    return removed_count

def cleanup_folder(folder_path):
    protected_extensions = {'.bat', '.cmd', '.reg', '.ps1', '.vbs', '.pow', '.py'}
    
    # Получаем размер папки до очистки
    initial_size = get_folder_size(folder_path)
    print(f"Начальный размер папки: {format_size(initial_size)}")
    
    # Рекурсивно обходим все файлы и папки
    for root, dirs, files in os.walk(folder_path, topdown=False):
        for file in files:
            file_path = os.path.join(root, file)
            file_ext = os.path.splitext(file)[1].lower()
            
            # Удаляем файл, если его расширение не в списке защищенных
            if file_ext not in protected_extensions:
                try:
                    os.remove(file_path)
                    print(f"Удален файл: {file_path}")
                except Exception as e:
                    print(f"Ошибка при удалении {file_path}: {e}")
    
    # Первая проверка на пустые папки
    print("\nПервая проверка на пустые папки...")
    remove_empty_folders(folder_path)
    
    # Повторная проверка на пустые папки (на случай, если после удаления первой папки появились новые пустые)
    print("\nПовторная проверка на пустые папки...")
    while remove_empty_folders(folder_path) > 0:
        pass
    
    # Получаем размер папки после очистки
    final_size = get_folder_size(folder_path)
    print(f"\nКонечный размер папки: {format_size(final_size)}")
    freed_space = initial_size - final_size
    print(f"Освобождено места: {format_size(freed_space)}")
    print(f"Освобождено мегабайт: {freed_space / (1024 * 1024):.2f} МБ")

if __name__ == "__main__":
    # Получаем путь к текущей папке
    current_folder = os.path.dirname(os.path.abspath(__file__))
    print(f"Очистка папки: {current_folder}")
    cleanup_folder(current_folder) 