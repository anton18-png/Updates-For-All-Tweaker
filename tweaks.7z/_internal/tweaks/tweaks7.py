tabs = {

'1 ПОЧТИ ДЛЯ ВСЕХ ПРОБЛЕМ': ['Открой от имени Администратора.bat', 'Сделать бэкап служб.vbs', 'FixWin10.2.2\\FixWin 10.2.2.exe'],

'BCD бекап': ['BCD ТВИКИ ВЕРНУТЬ.cmd.cmd'],

'DirectX сброс': ['DirectX default - вернуть все как было.bat'],

'Fortnite дефолт настройки': ['Default Fortnite Priority.reg'],

'HDCP сброс': ['Disable HDCP Revert.bat'],

'Microsoft store': ['store.exe'],

'ping fix': ['Clear DNS Cache (Ping Improve).cmd'],

'Uvm сброс': ['Uvm Revert.reg'],

'WIFI': ['Fix Disabled WiFi (RUN AS ADMIN).bat'],

'Вернуть game bar': ['Game Bar.reg'],

'Вернуть LockScreen': ['LockScreen.bat'],

'Вернуть Logitech Gaming': ['Logitech Gaming.bat'],

'Вернуть Media Player': ['de3nake-медиа.bat'],

'Вернуть Razer Game Scanner': ['Razer Game Scanner.bat'],

'Вернуть все службы по дефолту': ['2 Дефолт службы win 10-11.reg', '3 PowerRun.exe'],

'Вернуть драйвера': ['For recent drivers.bat'],

'Вернуть конфигурацию браузеров': ['DE3NAKE-БРАЗУЕРЫ.bat'],

'Вернуть новое контекстное меню': ['2) W11 Вернуть новое контекстное меню.reg'],

'Вернуть поиск': ['DE3NAKE-ПОИСК.bat'],

'Вкл мягчение последствий valorant': ['Enable Mitigations (fixes valorant).bat'],

'Включить AmdPPM': ['Enable AmdPPM.reg'],

'Включить BasicDisplay': ['Enable  BasicDisplay.reg'],

'Включить BIOS управления': ['Enable Management BIOS.bat'],

'Включить Bluetooth': ['privacy-script.bat'],

'Включить Defender': ['DE3NAKE-DEF.bat'],

'Включить FSO': ['turn on FSO.bat'],

'Включить QoS': ['Enable QoS.reg'],

'Включить UEFI': ['Enable UEFI.reg'],

'Включить антивирус Windows': [],

'Включить брэндмаузер': [],

'Включить виджеты': ['3) W11 Включить виджеты.reg'],

'Включить диспетчер задач по умолчанию': ['Enable Default Task Manager.reg'],

'Включить драйверы безопасности': ['Enable Security Drivers.reg'],

'Включить индексирование поиск': ['DE3NAKE.bat'],

'Включить микрофон': ['2privacy-script.bat'],

'Включить работу программ в фоне': ['1) W11 Включить работу программ в фоне.reg'],

'Включить спектре': ['2) Включить Spectre, Meldown, Tsx.reg'],

'Включить телеметрию NVIDIA': ['Откатить телеметрию Nvidia.bat'],

'Включить энергосбережение драйвера': ['Включить энергосбережение драйвера видеокарты.reg'],

'Восстановить все папки с мой комьютер': ['Восстановить всё.reg'],

'Восстановить оптимизацию для игр': ['2) Восстановить оптимизацию для игр.ps1'],

'Восстановить электропитание по умолчанию': ['Открой от имени Администратора.bat'],

'Восстановить энергосбережение': ['1) Восстановить энергосбережение.ps1'],

'Восстановления службы программного поставщика теневого копирования': ['Открой от имени Администратора.bat'],

'Долгое выключение ПК': ['Это приложение не позволяет выключить ПК.reg'],

'Долгое сворачивание полноэкранных приложений (старых игр)': [],

'Драйвера сети для виртуальных машин': [],

'Если пропал WIFI': ['Пофиксить Wi-Fi.reg', 'Так же обязптельно к активации!.reg'],

'Если пропала камера': ['Enable Webcam.bat'],

'Загрузка в steam': [],

'Иконки wifi': ['fix-network-icon-step-1.bat', 'fix-network-icon-step-2.bat'],

'Исправить приложения windows': [],

'Исправления alt tab': [],

'Микро лаги в Fortnite': ['1000hz.cmd', 'Fix Sense.reg'],

'Микрофон': [],

'Не запускается fortine': ['Fix Fortnite Not Starting (RUN AS ADMIN).bat'],

'Не запускается Fortnite х2': ['Default Fortnite Priority.reg'],

'Не красивый шрифт': ['Default Font Smoothing.reg'],

'Не работает AntiLag': ['2 Autoruns.exe', '3 AntiLag.exe'],

'Не работает буфер обмена WIN + V': ['1 Запусти о имени админа.bat', '2 От имени Администратора.bat'],

'Не работает сеть (Драйвера)': [],

'Обновление windows': ['Включить обновление Windows.bat'],

'Обновление и Безопасность': ['От имени Администратора.bat'],

'Обычный приоритет Fortnite': ['Default Valorant Priority.reg'],

'Откат твиков интернета': ['Oткат твиков интернета2.reg'],

'Отключить игровой режим': ['Отключить игровой режим.reg'],

'Панель nvidia': ['panel nvidia.bat'],

'Папки в этот компьютер': ['службы.bat'],

'Плавает мышь': ['Fix Sens .reg'],

'Повысилась температура': [],

'Поиск': ['ctfmon.exe'],

'Пропал поиск': ['включить поиск (ипользуй Nsudo).bat'],

'Пропала папка Recent': ['Открой от имени Администратора.bat'],

'Просит сменить пороль': [],

'Резка сенса': ['1резкаясенса.reg', '2резкаясенса.reg', 'Mouse 3.bat'],

'Сброс графических драйверов': ['Graphics Drivers Tweaks Revert.reg'],

'Сброс зондирования интернета': ['Internet Probing Revert .reg'],

'Сброс интернета': ['!Reset Network.bat'],

'Статеры в играх': ['ipconfig release.bat'],

'Телеметрия': ['disable telemetry fix net.bat'],

'Упал ФПС в играх': [],

'Фейсит AC': ['enable dep faceit fix.bat', 'Fix Faceit.bat'],

'Фикс Bluetooth': ['1 Включить службы Bluetooth.reg', '111221.bat', '2 Включить службы.reg', '3 Пофиксить Bluetooth.reg'],

'Фикс вылета RAGE MP': ['1 Открой.bat', '2 Открой.reg'],

'Фикс Интернета': ['Восстановить - понижение пинга.bat', 'Пофиксить Wi-Fi.reg', 'Сбросить настройки сети.bat', 'Фикс 90% случаев.bat', 'Если не помогло\\2 WinCry.exe', 'Фикс Интернет иконок\\fix-network-icon-step-1.bat', 'Фикс Интернет иконок\\fix-network-icon-step-2.bat'],

'Фикс мыши': ['FixMouse.bat'],

'Фикс мыши 2': ['fixsens.nip', 'Mouse Optimizations.reg', 'nvidiaProfileInspector.exe', 'макс отклик.reg'],

'Чёрный экран при сворачивании': ['От имени Администратора.bat'],}