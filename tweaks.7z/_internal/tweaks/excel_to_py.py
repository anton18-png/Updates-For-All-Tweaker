import openpyxl
import os

def excel_to_python():
    # Открываем Excel файл
    wb = openpyxl.load_workbook('tabs111111.xlsx')
    
    # Создаем словарь для хранения данных
    data_dict = {}
    
    # Обрабатываем каждый лист
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        
        # Получаем все папки (заголовки столбцов)
        folders = []
        for col in range(1, ws.max_column + 1):
            folder = ws.cell(row=1, column=col).value
            if folder:
                folders.append(folder)
        
        # Создаем список файлов для каждой папки
        for folder in folders:
            col_idx = folders.index(folder) + 1
            files = []
            
            # Собираем все файлы из столбца
            for row in range(2, ws.max_row + 1):
                file_name = ws.cell(row=row, column=col_idx).value
                if file_name:
                    # Восстанавливаем полный путь к файлу
                    full_path = os.path.join(folder, file_name)
                    files.append(full_path)
            
            # Добавляем в словарь
            if sheet_name not in data_dict:
                data_dict[sheet_name] = {}
            data_dict[sheet_name][folder] = files
    
    # Создаем Python файл
    with open('tabs_beta_alt.py', 'w', encoding='utf-8') as f:
        # Записываем импорты и комментарии
        f.write('# -*- coding: utf-8 -*-\n\n')
        
        # Записываем каждую переменную
        for sheet_name, folders in data_dict.items():
            var_name = f'tabs_{sheet_name.lower()}' if sheet_name != 'Главное' else 'tabs_main'
            f.write(f'{var_name} = {{\n')
            
            for folder, files in folders.items():
                f.write(f"    '{folder}': [\n")
                for file in files:
                    f.write(f"        '{file}',\n")
                f.write('    ],\n')
            
            f.write('}\n\n')

if __name__ == '__main__':
    excel_to_python()
    print('Файл tabs_beta_alt.py успешно создан!') 