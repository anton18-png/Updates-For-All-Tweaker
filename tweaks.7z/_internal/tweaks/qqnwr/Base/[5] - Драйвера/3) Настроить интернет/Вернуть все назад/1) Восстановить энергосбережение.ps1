if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }

Set-ExecutionPolicy Unrestricted

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Energy-Efficient Ethernet"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "����������������� Ethernet"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Ultra Low Power Mode"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Ultra Low Power Mode"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Green Ethernet"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "������� Ethernet"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Gigabit Lite"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Gigabit Lite"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Power Saving Mode"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Power Saving Mode"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Auto Disable Gigabit"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "�������������� ���������� ��������"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Advanced EEE"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Advanced EEE"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Packet Coalescing"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "����������� �������"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "MIMO power save mode"
Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "����� ���������������� MIMO"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "EEELinkAdvertisement"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "ReduceSpeedOnPowerDown"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "PowerSavingMode"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "ULPMode"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "GigaLite"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "EnableSavePowerNow"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "EnablePowerManagement"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "AutoPowerSaveModeEnabled"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "PowerDownPll"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "S5NicKeepOverrideMacAddrV2"

Reset-NetAdapterAdvancedProperty -Name "*" -DisplayName "Enable PME"