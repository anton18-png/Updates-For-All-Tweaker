tabs = {

'Браузеры': ['Cent Browser.bat', 'Thorium.bat'],

'Игровые платформы': ['Battle.net.bat', 'Epic Games Launcher.bat', 'Origin.bat', 'Steam.bat', 'Ubisoft Connect.bat'],

'Оптимизация': ['Bulk Crap Uninstaller.bat', 'Dism++.bat', 'Mem Reduct.bat'],

'Приватность': ['O&O ShutUp10++.bat', 'SimpleDnsCrypt.bat', 'simplewall.bat', 'smsniff.bat', 'W10Privacy.bat'],

'Программы для общения и стриминга': ['Discord.bat', 'OBS Studio.bat', 'Twitch.bat'],

'Твикеры': ['Bat Твикеры\\AncelsPerformanceBatch RUS By Igromanoff.bat', 'Bat Твикеры\\Ghost Tweaker.bat', 'Bat Твикеры\\HoneCtrl.bat', "Bat Твикеры\\Igromanoff TWEAK's V1.3.bat", 'Bat Твикеры\\ToX_Free_Utility_v1.6.bat', 'Bat Твикеры\\zl tweaks.bat'],

'Торрент-клиенты': ['Deluge.bat', 'qBittorrent.bat'],}