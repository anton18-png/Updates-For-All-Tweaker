import tkinter as tk
from tkinter import ttk
import os
from telemetry.logger import Logger

logger = Logger()

def create_fixes_tab(tab_control):
    # Создаем вкладку для исправлений
    fixes_tab = ttk.Frame(tab_control)
    tab_control.add(fixes_tab, text='Исправления')
    
    # Создаем основной контейнер с прокруткой
    main_container = ttk.Frame(fixes_tab)
    main_container.pack(fill='both', expand=True, padx=10, pady=10)
    
    # Создаем канвас с вертикальным скроллбаром
    canvas = tk.Canvas(main_container)
    scrollbar = ttk.Scrollbar(main_container, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas)
    
    # Настройка прокрутки
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    # Упаковка элементов
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    # Привязка колесика мыши
    def on_mousewheel(event):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    canvas.bind_all("<MouseWheel>", on_mousewheel)
    
    # Словарь для хранения чекбоксов
    checkboxes = {}
    
    # Получаем данные из tweaks7.py
    from tweaks.tweaks7 import tabs
    
    # Создаем основной фрейм для таблицы
    table_frame = ttk.Frame(scrollable_frame)
    table_frame.pack(fill='both', expand=True)
    
    # Группируем категории по три
    categories = list(tabs.keys())
    category_triples = [categories[i:i+3] for i in range(0, len(categories), 3)]
    
    # Создаем строки с тройками категорий
    for row, triple in enumerate(category_triples):
        row_frame = ttk.Frame(table_frame)
        row_frame.pack(fill='x', pady=5)
        
        for col, category in enumerate(triple):
            # Создаем фрейм для категории
            category_frame = ttk.LabelFrame(row_frame, text=category)
            category_frame.grid(row=0, column=col, padx=5, sticky='nsew')
            
            # Устанавливаем фиксированную ширину для колонки
            row_frame.grid_columnconfigure(col, minsize=500)
            
            # Создаем чекбоксы для файлов в категории, если они есть
            if tabs[category]:
                for i, file_name in enumerate(tabs[category]):
                    checkbox_var = tk.BooleanVar()
                    checkbox = ttk.Checkbutton(
                        category_frame,
                        text=file_name,
                        variable=checkbox_var
                    )
                    checkbox.grid(row=i, column=0, sticky='w', padx=5, pady=1)
                    checkboxes[file_name] = checkbox_var
                    # выводим имя фрейма, в котором находится чекбокс
                    # print(f'{category}\\{file_name}')
            else:
                # Если категория пустая, добавляем сообщение
                empty_label = ttk.Label(category_frame, text="Нет доступных файлов")
                empty_label.grid(row=0, column=0, padx=5, pady=5)
    
    # Функция для выполнения выбранных чекбоксов
    def execute_selected():
        selected_files = [name for name, var in checkboxes.items() if var.get()]
        if not selected_files:
            logger.log_warning("Не выбрано ни одного файла для выполнения")
            return

        for category, files in tabs.items():
            for file_name in files:
                if file_name in selected_files:
                    new_file_name = f'{category}\\{file_name}'
                    # print('--------------------------------')
                    # print(new_file_name)
                    # print('--------------------------------')

        for file_name in selected_files:
            try:
                # Определяем путь к файлу
                file_path = os.path.join('tweaks', 'Исправления', new_file_name)
                print(new_file_name)
                
                # Выполняем файл в зависимости от расширения
                if file_name.endswith('.bat'):
                    os.system(f'start /wait cmd /c "{file_path}"')
                elif file_name.endswith('.reg'):
                    os.system(f'reg import "{file_path}"')
                elif file_name.endswith('.exe'):
                    os.system(f'"{file_path}"')
                elif file_name.endswith('.ps1'):
                    os.system(f'powershell -ExecutionPolicy Bypass -File "{file_path}"')
                
                logger.log_info(f"Выполнен файл: {file_name}")
            except Exception as e:
                logger.log_error(f"Ошибка при выполнении файла {file_name}: {str(e)}")
    
    # Кнопка для выполнения выбранных чекбоксов
    execute_btn = ttk.Button(
        scrollable_frame,
        text="Выполнить выбранное",
        command=execute_selected
    )
    execute_btn.pack(pady=10)
    
    return fixes_tab 